/*
 * File:   Main.c
 * Author: SEA - Aitor VA
 * D.E.P. - GiTELE - 2019-2020
 */

/* 
 * File:   Main.c
 * Author: AVA

 */

/* Este proyecto tiene como objetivo proveer los archivos base y la estructura
 * T�pica de programaci�n para usar durante la asignatura. L�ease con atenci�n
 * las recomendaciones y las instrucciones de uso.
 */

// SIEMPRE SE INCLUIR�N ESTOS ARCHIVOS DE CABECERA:
#include "Config.h"
#include "Main.h"
#include "Func.h"
#include "dsp.h"



//---------------------------------------------------------------------------
// Global variables
float duty=0.5;
unsigned int posicion=0;
float rms_sen,max_sen,med_sen; //Valores de RMS, valores m�ximos y medios para las dos se�ales
float rms_tri,max_tri,med_tri;
float senoidal[MUESTRAS];
float triangular[MUESTRAS];

//---------------------------------------------------------------------------
// En este espacio pueden declararse las variables globales o las constantes.
// Ejemplo:
// unsigned int MiValor = 0;


//---------------------------------------------------------------------------
// ISR routine
//---------------------------------------------------------------------------

// Llamada a la subrutina de interrupci�n. Descomentar estas l�neas para activarla.
// Debe incluirse el nombre de la rutina de interrupci�n (vector de interrupci�n).
// Esta llamada a la funci�n de interrupci�n debe repetirse tantas veces como
// vectores de interrupci�n haya (cada una, con su vector correspondiente)

void __attribute__((interrupt, auto_psv)) _ADCInterrupt(void)
{
    IFS0bits.ADIF=0;        //Limpiar el flap
    //Variables del ADC en voltios
    triangular[posicion]=ADCBUFA*(5.0/4095);
    senoidal[posicion]=ADCBUFB*(5.0/4095);
    
    //ADC ON
    ADCON1bits.ADON=1; 
    
    posicion++;
    if(posicion>MUESTRAS)
        posicion=1;
    
}
void __attribute__((interrupt, auto_psv)) _T1Interrupt(void)
{
        
    IFS0bits.T1IF = 0;
    T1CONbits.TON = 0;
    
    TMR1 = 0;     //Limpio registro
    
    InitLCD();
    
    //Variables a mostrar
    rms_sen= RMS(senoidal, MUESTRAS);
    max_sen= Maximo(senoidal, MUESTRAS);
    med_sen= valorMedio(senoidal, MUESTRAS);
    
    rms_tri= RMS(triangular, MUESTRAS);
    max_tri= Maximo(triangular, MUESTRAS);
    med_tri= valorMedio(triangular, MUESTRAS);
    
    
    
    
    MostrarLCD(rms_sen, max_sen, med_sen, rms_tri, max_tri, med_tri);
   
    T1CONbits.TON = 1;  //Arrancar TMR1
}

//---------------------------------------------------------------------------
// Main routine
//---------------------------------------------------------------------------

// Funci�n principal. Siempre incluye un bucle infinito.

int main (void)
{   InitIO();
    // Aqu� se declarar�an las variables LOCALES a la funci�n Main.
    GenPwm(duty);
    InitTMR1();
    InitTMR3();
    InitADC();
    ConfigInt();
    InitLCD();
    
    T1CONbits.TON=1;    //TMR1 ON
    T2CONbits.TON=1;  //TMR2 ON
    T3CONbits.TON=1;  //TMR3 ON
    
    
    while (1)   // bucle infinito
    {
   
    }
    
    return 0;
    
}// Main
