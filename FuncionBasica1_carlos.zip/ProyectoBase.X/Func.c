#include "Func.h"
#include "Main.h"

/* Este archivo contendr� la definici�n de las funciones auxiliares que se
 * necesiten para la ejecuci�n del c�digo.
 * Pueden a�adirse tantas como se quiera.
 * El objetivo es encapsular lo m�ximo posible el c�digo y reutilizar todas las+
 * funciones posibles.
 * En el archivo FUNC.H deber�n incluirse los prototipos de estas funciones.
 */

// Ejemplo:
// FUNCI�N PARA INICIALIZACI�N DE PUERTOS E/S
// Par�metros de entrada: ninguno (void).
// Par�metros de salida: ninguno (void).
void InitIO()
{
    LATD = 0xFFFF;                //Turn off all LEDS
    TRISD = 0xFFFF;               //RB10,RB11 OUTPUTS
    TRISA = 0xFFFE;               //RB0 INPUT
    return;
}// InitIO

void InitADC()
{   
    // ADCON1 CONFIGURATION
    ADCON1bits.ADON = 0;        // Initially, stopped.
    ADCON1bits.ADSIDL = 0;      // No IDLE
    ADCON1bits.FORM = 0b00;     // Output format = unsigned integer PARA QUE EL FORMATO DE SALIDA DE LOS DATOS ENTERO SINSIGNO
    ADCON1bits.SSRC = 0b010;    // Source for triggering conversion = auto SI QUIERO QUE DISPARE AUTOMATICAMENTE O LANZE LA CONVERSION POR TIMER 3
    ADCON1bits.ASAM = 1;        // Sampling after conversion ends

    
    // ADCON2 CONFIGURATION
    ADCON2bits.VCFG = 0b000;    // Vref+ = VDD, Vref- = VSS.  QUE TOME COMO REFERENCIA VDD Y NEGATIVA MASA
    ADCON2bits.SMPI = 0b1110;   // Interrupts after 15 conversionS
    ADCON2bits.BUFM = 0;        // 16 words
    ADCON2bits.CSCNA = 1;
    ADCON2bits.ALTS = 0;
    ADCON2bits.BUFS = 0;
           
    // ADCON3 CONFIGURATION
    ADCON3bits.SAMC = 0b01111;   // 15�Tad 
    ADCON3bits.ADCS = 4;        // Clock Tad
    ADCON3bits.ADRC = 0;        // internal clock
    
    
    // ADCPCFG
    ADPCFG = 0xFFFF;            //analog input
    ADPCFGbits.PCFG10 = 0;      
    ADPCFGbits.PCFG11 = 0;
    
    
    
    
    // ADCSSL
    ADCSSL = 0x0000;            // NO ESTA ACTIVO PARA LA COMVERSION, QUE TE PERMITA LANZAR CONVERSIONES AD EN ESE PIN
    ADCSSLbits.CSSL10 = 1;      // RB10 conversion
    ADCSSLbits.CSSL11 = 1;      //RB11 conversion
    
    
    ADCON1bits.ADON = 1;        // turn ADC ON

    return;
}
void ConfigInt()
{
    // Configuring the interrupts
    INTCON1bits.NSTDIS = 1;         // Disable nesting interrputs 
    // Timer 1
    IFS0bits.T1IF = 0;              // Clean flag   
    IEC0bits.T1IE = 1;              // Set local mask
    IPC0bits.T1IP = 4;              // Set priority level
    //ADC
    IFS0bits.ADIF = 0;              // Clean flag   
    IEC0bits.ADIE = 1;              // Set local mask
    IPC2bits.ADIP = 5;              // Set priority level
    
    SET_CPU_IPL(3);                 // Set CPU priority level (always lower than the previous one)

    return;   
}
void InitTMR1()
{   
    //------------------------------------------------------------------------------
    //Initialize Timer1 for  period
    T1CON = 0;                    // Turn off Timer3 by clearing control register
	TMR1 = 0;                     // Start Timer1 at zero
	PR1 = (FCY/256)*0.5;         // Set period register value 
    T1CON = 0x0030;               // Configure Timer3 (timer off, continue in IDLE, not gated, 1:256 prescaler, internal clock)    
    return;
}
void InitTMR3()
{   
    //------------------------------------------------------------------------------
    //Initialize Timer3 for  period
    T3CON = 0;                    // Turn off Timer3 by clearing control register
	TMR3 = 0;                     // Start Timer1 at zero
	PR3 = (FCY/256)*0.0004;         // Set period register value -> frecuencia de muestreo 2500
    T3CON = 0x0030;               // Configure Timer3 (timer off, continue in IDLE, not gated, 1:256 prescaler, internal clock)    
    return;
}
void GenPwm(float duty){
    if(duty>1)
        duty=0.9;
    if(duty<0)
        duty=0.1;
    
    PR2=FCY/737;
    T2CON= 0x0000;
    OC1CONbits.OCTSEL=0;    //Se selecciona el TMR2
    OC1CONbits.OCSIDL=0;    // funciona modo IDL
    OC1CONbits.OCM=0b110;  //PWM mode
    OC1RS=duty*PR2;
    return;
    
    
    
}

float Maximo(float vec[],unsigned int muestras){
    float max=0.0;
    unsigned int i;
    for(i=0;i<muestras;i++){
        if(vec[i]>max)
            max=vec[i];
    }
    return max;
}

float valorMedio(float vec[],unsigned int muestras){
    float sum=0.0;
    unsigned int i;
    for(i=0;i<muestras;i++){
        sum=sum+vec[i];
    }
    return (sum/muestras);
}

float RMS(float vec[],unsigned int muestras){
    float sum=0.0;
    unsigned int i;
    float rms_c=1;
    for(i=0;i<muestras;i++){
        sum=sum+pow(vec[i],2);
    }
    rms_c=sqrt((1.0/muestras)*sum);
    return rms_c;
}
//Inicializaci�n de LCD
void InitLCD(void)
{
LCD_Display_Setup(); // INICIALIZA LCD
LCD_Display_Byte(HOME_CLEAR); // BORRA LCD
LCD_Display_Byte(CURSOR_ON); // PONE CURSOR
}

//Pantalla LCD

void MostrarLCD(float rms_sen, float max_sen, float med_sen, float rms_tri, float max_tri, float med_tri)
{
    unsigned int tamano = 30;
    char fila1[tamano];
    char fila2[tamano];
    char fila3[tamano];
    char fila4[tamano];
    
    sprintf(fila1, "10: M=%.2fV; m=%.2fV",max_tri,med_tri);
    sprintf(fila4,"11: rms=%.2fV\n",rms_sen );
    sprintf(fila3, "11: M=%.2fV; m=%.2fV",max_sen,med_sen);
    sprintf(fila2,"10: rms=%.2fV\n",rms_tri );

    unsigned int TxIndex = 0;
    while(fila1[TxIndex]){
        LCD_Display_Byte(WRITE_CHAR);
        LCD_Display_Byte(fila1[TxIndex++]);
    }
    TxIndex = 0;
    while(fila2[TxIndex]){
        LCD_Display_Byte(WRITE_CHAR);
        LCD_Display_Byte(fila2[TxIndex++]);
    }
    TxIndex = 0;
    while(fila3[TxIndex]){
        LCD_Display_Byte(WRITE_CHAR);
        LCD_Display_Byte(fila3[TxIndex++]);
    }
    TxIndex = 0;
    while(fila4[TxIndex]){
        LCD_Display_Byte(WRITE_CHAR);
        LCD_Display_Byte(fila4[TxIndex++]);
    }
}
