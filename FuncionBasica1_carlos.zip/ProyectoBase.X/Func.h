/* 
 * File:   Func.h
 * Author: AVA
 *
 */

/* En este archivo deben incluirse los prototipos de las funciones utilizadas en
 * FUNC.C.
 */

#ifndef FUNC_H
#define	FUNC_H

// EJEMPLO:
void InitIO(void);
void GenPwm(float);
void InitADC(void);
void ConfigInt(void);
void InitTMR1(void);
void InitTMR3(void);
float Maximo(float *,unsigned int);
float RMS(float *,unsigned int);
float valorMedio(float *,unsigned int);
void InitLCD(void);
void MostrarLCD(float , float , float, float, float, float);




// A�adir tantos prototipos como sea necesario.

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* FUNC_H */

